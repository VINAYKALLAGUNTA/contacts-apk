package app.contactnotebook;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_PERMISSIONS = 11;
    private static final int INK = 0xFF1B2733;
    private static final int SOFT = 0xFF55677A;
    private static final int WARN = 0xFFA0521D;
    private static final int ACCENT = 0xFF1F5F8B;

    private Db db;
    private final List<Db.Row> rows = new ArrayList<Db.Row>();
    private BaseAdapter adapter;
    private TextView summary;
    private EditText search;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ContentObserver observer;
    private boolean syncing = false;

    private final Runnable syncRunnable = new Runnable() {
        @Override
        public void run() {
            runSync();
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new Db(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFEEF2F6);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));

        TextView title = new TextView(this);
        title.setText("Contact Notebook");
        title.setTextSize(26);
        title.setTextColor(INK);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        summary = new TextView(this);
        summary.setTextSize(14);
        summary.setTextColor(SOFT);
        summary.setPadding(0, dp(4), 0, dp(10));
        root.addView(summary);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.addView(makeButton("Sync now", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runSync();
            }
        }));
        buttons.addView(makeButton("Copy CSV", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyCsv();
            }
        }));
        buttons.addView(makeButton("Share CSV", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareCsv();
            }
        }));
        root.addView(buttons);

        search = new EditText(this);
        search.setHint("Search name or number");
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setTextColor(INK);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                refresh();
            }
        });
        root.addView(search);

        ListView list = new ListView(this);
        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return rows.size();
            }

            @Override
            public Object getItem(int i) {
                return rows.get(i);
            }

            @Override
            public long getItemId(int i) {
                return rows.get(i).id;
            }

            @Override
            public View getView(int i, View convertView, ViewGroup parent) {
                Db.Row r = rows.get(i);
                LinearLayout box = new LinearLayout(MainActivity.this);
                box.setOrientation(LinearLayout.VERTICAL);
                box.setPadding(dp(4), dp(10), dp(4), dp(10));

                TextView name = new TextView(MainActivity.this);
                name.setTextSize(16);
                name.setTypeface(null, Typeface.BOLD);
                if (r.name.isEmpty()) {
                    name.setText("No name yet. Tap to add one");
                    name.setTextColor(WARN);
                } else {
                    name.setText(r.name);
                    name.setTextColor(INK);
                }

                TextView tel = new TextView(MainActivity.this);
                tel.setTextSize(14);
                tel.setTypeface(Typeface.MONOSPACE);
                tel.setTextColor(SOFT);
                tel.setText(r.tel);

                box.addView(name);
                box.addView(tel);
                return box;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                editRow(rows.get(position));
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        observer = new ContentObserver(ui) {
            @Override
            public void onChange(boolean selfChange) {
                ui.removeCallbacks(syncRunnable);
                ui.postDelayed(syncRunnable, 2000);
            }
        };

        requestMissingPermissions();
        refresh();
        runSync();
    }

    private Button makeButton(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(ACCENT);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    @Override
    protected void onStart() {
        super.onStart();
        getContentResolver().registerContentObserver(
                ContactsContract.Contacts.CONTENT_URI, true, observer);
        getContentResolver().registerContentObserver(
                CallLog.Calls.CONTENT_URI, true, observer);
    }

    @Override
    protected void onStop() {
        super.onStop();
        getContentResolver().unregisterContentObserver(observer);
        ui.removeCallbacks(syncRunnable);
    }

    private void requestMissingPermissions() {
        List<String> missing = new ArrayList<String>();
        if (!Sync.has(this, Manifest.permission.READ_CONTACTS))
            missing.add(Manifest.permission.READ_CONTACTS);
        if (!Sync.has(this, Manifest.permission.READ_CALL_LOG))
            missing.add(Manifest.permission.READ_CALL_LOG);
        if (Build.VERSION.SDK_INT >= 33
                && !Sync.has(this, Manifest.permission.POST_NOTIFICATIONS))
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        runSync();
    }

    private void runSync() {
        if (syncing) return;
        syncing = true;
        summary.setText("Syncing...");
        final Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Sync.run(app);
                } catch (Throwable ignored) {
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        syncing = false;
                        Jobs.schedule(app);
                        refresh();
                    }
                });
            }
        }).start();
    }

    private void refresh() {
        rows.clear();
        rows.addAll(db.list(search.getText().toString()));
        adapter.notifyDataSetChanged();

        int total = db.count();
        int unnamed = db.countUnnamed();
        StringBuilder sb = new StringBuilder();
        sb.append(total).append(total == 1 ? " number saved" : " numbers saved");
        if (unnamed > 0) sb.append(", ").append(unnamed).append(" need a name");
        if (!Sync.has(this, Manifest.permission.READ_CONTACTS)) {
            sb.append("\nContacts access is off, so contacts are not being saved.");
        }
        if (!Sync.has(this, Manifest.permission.READ_CALL_LOG)) {
            sb.append("\nCall log access is off, so numbers from calls are not being saved.");
        }
        summary.setText(sb.toString());
    }

    private void editRow(final Db.Row row) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Name");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        input.setText(row.name);
        input.setSelection(input.getText().length());

        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(dp(20), dp(8), dp(20), 0);
        holder.addView(input);

        new AlertDialog.Builder(this)
                .setTitle(row.tel)
                .setView(holder)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        db.setName(row.id, input.getText().toString());
                        Notifier.update(getApplicationContext(), db);
                        refresh();
                    }
                })
                .setNeutralButton("Remove", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        db.remove(row.id);
                        Notifier.update(getApplicationContext(), db);
                        refresh();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String buildCsv() {
        StringBuilder sb = new StringBuilder("Name,Phone\r\n");
        for (Db.Row r : db.list("")) {
            sb.append(csvCell(safeName(r.name))).append(',').append(csvCell(r.tel)).append("\r\n");
        }
        return sb.toString();
    }

    /** Stops spreadsheets from treating a name as a formula. */
    private String safeName(String name) {
        if (name.startsWith("=") || name.startsWith("@") || name.startsWith("-") || name.startsWith("+")) {
            return "'" + name;
        }
        return name;
    }

    private String csvCell(String v) {
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    private void copyCsv() {
        if (db.count() == 0) {
            Toast.makeText(this, "Nothing to copy yet", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("contacts", buildCsv()));
        Toast.makeText(this, "Copied " + db.count() + " contacts as CSV", Toast.LENGTH_SHORT).show();
    }

    private void shareCsv() {
        if (db.count() == 0) {
            Toast.makeText(this, "Nothing to share yet", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Contact Notebook");
        send.putExtra(Intent.EXTRA_TEXT, buildCsv());
        startActivity(Intent.createChooser(send, "Share contacts"));
    }
}
