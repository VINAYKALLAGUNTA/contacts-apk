package app.contactnotebook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** Local notebook of names and numbers. Numbers are matched on their last 10 digits. */
public class Db extends SQLiteOpenHelper {

    public static class Row {
        public long id;
        public String name;
        public String tel;
        public String source;
    }

    public Db(Context context) {
        super(context.getApplicationContext(), "notebook.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE contacts ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL DEFAULT '',"
                + "tel TEXT NOT NULL,"
                + "norm TEXT NOT NULL UNIQUE,"
                + "source TEXT NOT NULL,"
                + "edited INTEGER NOT NULL DEFAULT 0,"
                + "deleted INTEGER NOT NULL DEFAULT 0,"
                + "created INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase d, int oldVersion, int newVersion) {
    }

    public static String norm(String tel) {
        if (tel == null) return "";
        String digits = tel.replaceAll("\\D", "");
        return digits.length() > 10 ? digits.substring(digits.length() - 10) : digits;
    }

    /**
     * Adds a number or improves the name of an existing one.
     * A name typed by the user is never overwritten. A removed number is never added back.
     * Returns true when a new number was added.
     */
    public synchronized boolean upsert(String name, String tel, String source) {
        String n = norm(tel);
        if (n.length() < 5) return false;
        String cleanName = name == null ? "" : name.trim();
        SQLiteDatabase d = getWritableDatabase();
        Cursor c = d.query("contacts", new String[]{"id", "name", "edited"},
                "norm = ?", new String[]{n}, null, null, null);
        try {
            if (!c.moveToFirst()) {
                ContentValues v = new ContentValues();
                v.put("name", cleanName);
                v.put("tel", tel.trim());
                v.put("norm", n);
                v.put("source", source);
                v.put("created", System.currentTimeMillis());
                d.insert("contacts", null, v);
                return true;
            }
            long id = c.getLong(0);
            String old = c.getString(1);
            boolean edited = c.getInt(2) != 0;
            boolean fromContact = "contact".equals(source);
            boolean take = !cleanName.isEmpty() && !edited
                    && (old.isEmpty() || (fromContact && !old.equals(cleanName)));
            if (take) {
                ContentValues v = new ContentValues();
                v.put("name", cleanName);
                d.update("contacts", v, "id = ?", new String[]{String.valueOf(id)});
            }
            return false;
        } finally {
            c.close();
        }
    }

    public synchronized List<Row> list(String query) {
        List<Row> out = new ArrayList<>();
        String where = "deleted = 0";
        String[] args = null;
        if (query != null && !query.trim().isEmpty()) {
            where += " AND (name LIKE ? OR tel LIKE ?)";
            String like = "%" + query.trim() + "%";
            args = new String[]{like, like};
        }
        Cursor c = getReadableDatabase().query("contacts",
                new String[]{"id", "name", "tel", "source"}, where, args, null, null,
                "CASE WHEN name = '' THEN 0 ELSE 1 END, name COLLATE NOCASE, id");
        try {
            while (c.moveToNext()) {
                Row r = new Row();
                r.id = c.getLong(0);
                r.name = c.getString(1);
                r.tel = c.getString(2);
                r.source = c.getString(3);
                out.add(r);
            }
        } finally {
            c.close();
        }
        return out;
    }

    public synchronized int count() {
        return (int) DatabaseUtils.queryNumEntries(getReadableDatabase(), "contacts", "deleted = 0");
    }

    public synchronized int countUnnamed() {
        return (int) DatabaseUtils.queryNumEntries(getReadableDatabase(), "contacts",
                "deleted = 0 AND name = ''");
    }

    public synchronized void setName(long id, String name) {
        ContentValues v = new ContentValues();
        v.put("name", name == null ? "" : name.trim());
        v.put("edited", 1);
        getWritableDatabase().update("contacts", v, "id = ?", new String[]{String.valueOf(id)});
    }

    public synchronized void remove(long id) {
        ContentValues v = new ContentValues();
        v.put("deleted", 1);
        getWritableDatabase().update("contacts", v, "id = ?", new String[]{String.valueOf(id)});
    }
}
