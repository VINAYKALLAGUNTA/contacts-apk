package app.contactnotebook;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.provider.CallLog;
import android.provider.ContactsContract;

/** Schedules background syncs: every 15 minutes, and soon after contacts or the call log change. */
public class Jobs {

    private static final int JOB_PERIODIC = 1;
    public static final int JOB_ON_CHANGE = 2;

    public static void schedule(Context ctx) {
        JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        ComponentName service = new ComponentName(ctx, SyncJobService.class);
        if (js.getPendingJob(JOB_PERIODIC) == null) {
            js.schedule(new JobInfo.Builder(JOB_PERIODIC, service)
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true)
                    .build());
        }
        scheduleOnChange(ctx);
    }

    /** A content-trigger job runs once per change, so it must be scheduled again after every run. */
    public static void scheduleOnChange(Context ctx) {
        JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null) return;
        ComponentName service = new ComponentName(ctx, SyncJobService.class);
        JobInfo.Builder b = new JobInfo.Builder(JOB_ON_CHANGE, service);
        b.addTriggerContentUri(new JobInfo.TriggerContentUri(
                ContactsContract.Contacts.CONTENT_URI,
                JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS));
        b.addTriggerContentUri(new JobInfo.TriggerContentUri(
                CallLog.Calls.CONTENT_URI,
                JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS));
        b.setTriggerContentUpdateDelay(3000);
        b.setTriggerContentMaxDelay(15000);
        js.schedule(b.build());
    }
}
