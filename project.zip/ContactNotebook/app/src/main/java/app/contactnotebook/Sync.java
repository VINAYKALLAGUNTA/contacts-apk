package app.contactnotebook;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.CallLog;
import android.provider.ContactsContract;

/** Copies phone contacts and call log numbers into the notebook. Only reads from the phone. */
public class Sync {

    private static final String PREFS = "state";
    private static final String KEY_CALL_LAST = "calllog_last";

    public static boolean has(Context ctx, String permission) {
        return ctx.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    /** Returns how many new numbers were added. */
    public static synchronized int run(Context ctx) {
        Context app = ctx.getApplicationContext();
        Db db = new Db(app);
        int added = 0;
        try {
            if (has(app, Manifest.permission.READ_CONTACTS)) added += contacts(app, db);
        } catch (SecurityException ignored) {
        }
        try {
            if (has(app, Manifest.permission.READ_CALL_LOG)) added += calls(app, db);
        } catch (SecurityException ignored) {
        }
        Notifier.update(app, db);
        return added;
    }

    private static int contacts(Context ctx, Db db) {
        int added = 0;
        Cursor c = ctx.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER},
                null, null, null);
        if (c == null) return 0;
        try {
            while (c.moveToNext()) {
                String name = c.getString(0);
                String number = c.getString(1);
                if (number == null || number.trim().isEmpty()) continue;
                if (db.upsert(name, number, "contact")) added++;
            }
        } finally {
            c.close();
        }
        return added;
    }

    private static int calls(Context ctx, Db db) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long last = prefs.getLong(KEY_CALL_LAST, 0L);
        long max = last;
        int added = 0;
        Cursor c = ctx.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE},
                CallLog.Calls.DATE + " > ?",
                new String[]{String.valueOf(last)},
                CallLog.Calls.DATE + " ASC");
        if (c == null) return 0;
        try {
            while (c.moveToNext()) {
                String number = c.getString(0);
                String name = c.getString(1);
                long date = c.getLong(2);
                if (date > max) max = date;
                if (number == null || number.trim().isEmpty()) continue;
                if (db.upsert(name, number, "call")) added++;
            }
        } finally {
            c.close();
        }
        if (max > last) prefs.edit().putLong(KEY_CALL_LAST, max).apply();
        return added;
    }
}
