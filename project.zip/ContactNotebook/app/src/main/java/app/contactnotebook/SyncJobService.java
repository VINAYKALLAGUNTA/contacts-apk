package app.contactnotebook;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;

public class SyncJobService extends JobService {

    @Override
    public boolean onStartJob(final JobParameters params) {
        final Context ctx = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Sync.run(ctx);
                } catch (Exception ignored) {
                }
                if (params.getJobId() == Jobs.JOB_ON_CHANGE) {
                    Jobs.scheduleOnChange(ctx);
                }
                jobFinished(params, false);
            }
        }).start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return true;
    }
}
