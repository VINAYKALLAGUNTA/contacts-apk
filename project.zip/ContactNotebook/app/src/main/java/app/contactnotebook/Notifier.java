package app.contactnotebook;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/** Tells the user when saved numbers are waiting for a name. */
public class Notifier {

    private static final String CHANNEL = "needs_name";
    private static final int NOTIFICATION_ID = 1;

    public static void update(Context ctx, Db db) {
        int unnamed = db.countUnnamed();
        SharedPreferences prefs = ctx.getSharedPreferences("state", Context.MODE_PRIVATE);
        int lastShown = prefs.getInt("notified", 0);
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null) return;

        if (unnamed == 0) {
            nm.cancel(NOTIFICATION_ID);
            prefs.edit().putInt("notified", 0).apply();
            return;
        }
        if (unnamed <= lastShown) return;
        if (Build.VERSION.SDK_INT >= 33
                && !Sync.has(ctx, Manifest.permission.POST_NOTIFICATIONS)) return;

        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Numbers that need a name", NotificationManager.IMPORTANCE_DEFAULT));

        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        String title = unnamed == 1 ? "1 number needs a name" : unnamed + " numbers need a name";
        Notification n = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle(title)
                .setContentText("Tap to add names to your notebook")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(NOTIFICATION_ID, n);
        prefs.edit().putInt("notified", unnamed).apply();
    }
}
